(function ($) {
    "use strict";

    $("#sortable").sortable();

})(jQuery);